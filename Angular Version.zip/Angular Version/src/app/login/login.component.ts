import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BuyerserviceService } from '../buyerservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private buyerSer:BuyerserviceService,private router:Router) { }

  ngOnInit(): void {
    this.buyerSer.getBuyers();
  }
  custlogin = new FormGroup({
    email: new FormControl('', [Validators.email,Validators.required]),
    pass: new FormControl('',[Validators.required])
  });


  login() {
  
    let email = this.custlogin.get('email').value;
    let pass = this.custlogin.get('pass').value;
    
if(email!=""||pass!=""){
    this.buyerSer.checkUser(email,pass);
    if(this.buyerSer.flag) {
        this.router.navigateByUrl("/userHome"); 
    }
    else{
      document.getElementById("error").innerHTML="Email or Password is incorrect";
    }
    return;
  }
  else{
    document.getElementById("error").innerHTML="Fill all the fields!!";
    return;
  }
}
}
