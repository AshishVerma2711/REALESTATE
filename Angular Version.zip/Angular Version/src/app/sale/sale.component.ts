import { Component, OnInit } from '@angular/core';
import { SaleRequestService } from '../sale-request.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SaleRequest } from '../saleRequest';

@Component({
  selector: 'app-sale',
  templateUrl: './sale.component.html',
  styleUrls: ['./sale.component.css']
})
export class SaleComponent implements OnInit {

  constructor(private saleReq:SaleRequestService) { }
successFlag:boolean=false;

  ngOnInit(): void {
  }

  saleRequest=new FormGroup({
    name: new FormControl('',[Validators.minLength(2),Validators.required]),
    email: new FormControl('', [Validators.email,Validators.required]),
    phoneNumber: new FormControl('',[Validators.pattern('[0-9]{10}'),Validators.required]),
    
  });

  sendRequest(){
    let name =this.saleRequest.get('name').value;
    let email =this.saleRequest.get('email').value;
    let phoneNo =this.saleRequest.get('phoneNumber').value;

    if(name!=""&&email!=""&&phoneNo!=""){
        let tempReq:SaleRequest=new SaleRequest(name,email,phoneNo);
        this.saleReq.addSaleRequest(tempReq).subscribe(data=>
          {
            console.log(data)
            this.successFlag=true;
            this.saleRequest.reset(" ");
          }); 
    }
    else{
      document.getElementById("exists").innerHTML="Fill all the fields!"
    }

  }
}
