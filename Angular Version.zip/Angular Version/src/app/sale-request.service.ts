import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SaleRequest } from './saleRequest';
import { identifierModuleUrl } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class SaleRequestService {

  public saleReqDb:SaleRequest[]=[];

  constructor(private http: HttpClient) { }

  getSaleRequest(){
    this.http.get<SaleRequest[]>('http://localhost:3000/salerequest').subscribe(resp=>{
      for(const i of(resp as any)){
        this.saleReqDb.push({
            id:i.id,
            name:i.name,
            email:i.email,
            phoneNumber:i.phoneNumber,
          })
        }
      });
    }

    addSaleRequest(saleRequest:SaleRequest){
      return this.http.post('http://localhost:3000/salerequest',saleRequest);
    }
  }
