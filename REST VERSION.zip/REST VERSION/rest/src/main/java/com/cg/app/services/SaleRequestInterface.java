package com.cg.app.services;

import java.util.List;
import com.cg.app.dto.SaleRequest;

public interface SaleRequestInterface {
	SaleRequest addRequest(SaleRequest saleReq);
	List<SaleRequest> getAllSaleRequests();
}
