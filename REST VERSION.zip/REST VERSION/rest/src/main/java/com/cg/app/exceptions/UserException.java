package com.cg.app.exceptions;

public class UserException extends RuntimeException {

	public UserException(String message, Throwable cause) {
		super(message, cause);
	}

	public UserException(String message) {
		super(message);
	}

}
