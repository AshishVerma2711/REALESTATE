package com.cg.app.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="user")
public class User {
	@Id
	@Column(name = "id")
	String id;
	@Column(name="email")
	String email;
	@Column(name = "name")
	String name;
	@Column(name = "password")
	String password;
	@Column(name="phone_number")
	String phoneNo;
	@Column(name = "city")
	String city;
	@Column(name= "state")
	String state;
	
	public User() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public User(String id, String email, String name, String password, String phoneNo, String city, String state) {
		super();
		this.id = id;
		this.email = email;
		this.name = name;
		this.password = password;
		this.phoneNo = phoneNo;
		this.city = city;
		this.state = state;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", email=" + email + ", name=" + name + ", password=" + password + ", phoneNo="
				+ phoneNo + ", city=" + city + ", state=" + state + "]";
	}

}
