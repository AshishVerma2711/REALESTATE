package com.cg.app.exceptions;

public class SaleRequestException extends RuntimeException {

	public SaleRequestException(String message, Throwable cause) {
		super(message, cause);
	}

	public SaleRequestException(String message) {
		super(message);
	}

}
