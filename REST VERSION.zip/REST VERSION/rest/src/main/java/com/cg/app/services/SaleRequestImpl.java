package com.cg.app.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.dao.SaleRequestRepository;
import com.cg.app.dto.SaleRequest;
import com.cg.app.exceptions.SaleRequestException;

@Service
public class SaleRequestImpl implements SaleRequestInterface {

	@Autowired
	SaleRequestRepository saleRepo;

	@Override
	public SaleRequest addRequest(SaleRequest saleReq) {
		try{
			return saleRepo.save(saleReq);
		}
		catch(Exception e) {
			throw new SaleRequestException("Error While Sending Request");}
	}

	@Override
	public List<SaleRequest> getAllSaleRequests() {
		return (List<SaleRequest>)saleRepo.findAll();
	}

}
