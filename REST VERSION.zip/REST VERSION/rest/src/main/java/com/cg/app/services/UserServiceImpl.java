package com.cg.app.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.dao.UserRepository;
import com.cg.app.dto.User;
import com.cg.app.exceptions.UserException;

@Service
public class UserServiceImpl implements UserServiceInterface {
	@Autowired
	UserRepository userRepo;
	@Override
	public User addUser(User user) {
		userRepo.save(user);
		return null;
	}

	@Override
	public User updateUser(User user) {
		userRepo.save(user);
		return null;
	}

	@Override
	public List<String> getAllUserIds() {
		List<String> userIds = new ArrayList<String>();
		for(User user: userRepo.findAll()) {
			userIds.add(user.getEmail());
		}
		return userIds;
	}

	@Override
	public User checkCredentials(String email, String pass) {
		if(userRepo.getUserByEmail(email)!= null) {
			System.out.println(userRepo.existsByEmail(email));
			User user = userRepo.getUserByEmail(email);
			if(user.getPassword().equals(pass)) {
				System.out.println(user);
				return user;}
			else
				throw new UserException("Password Incorret");
		}
		else {
			throw new UserException("User ID Doesn't exist");
		}
}

	@Override
	public List<User> getAll() {
		return (List<User>)userRepo.findAll();
	}
}

