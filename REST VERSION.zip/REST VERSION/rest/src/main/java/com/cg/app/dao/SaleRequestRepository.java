package com.cg.app.dao;

import org.springframework.data.repository.CrudRepository;

import com.cg.app.dto.SaleRequest;

public interface SaleRequestRepository extends CrudRepository<SaleRequest, String> {

}
