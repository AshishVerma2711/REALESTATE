package com.cg.app.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="salerequest")
public class SaleRequest {
	@Id
	@GeneratedValue
	@Column(name = "id")
	String id;
	@Column(name="email")
	String email;
	@Column(name = "name")
	String name;
	@Column(name="phonenumber")
	String phoneNumber;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public SaleRequest(String email, String name, String phoneNumber) {
		super();
		this.email = email;
		this.name = name;
		this.phoneNumber = phoneNumber;
	}
	public SaleRequest() {
		super();
	}
	@Override
	public String toString() {
		return "SaleRequest [id=" + id + ", email=" + email + ", name=" + name + ", phoneNo=" + phoneNumber + "]";
	}
	
}
