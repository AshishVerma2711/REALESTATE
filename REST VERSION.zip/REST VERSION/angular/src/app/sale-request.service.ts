import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { SaleRequest } from './saleRequest';
import { identifierModuleUrl } from '@angular/compiler';
import { throwError, Observable } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SaleRequestService {

  public saleReqDb:SaleRequest[]=[];

  constructor(private http: HttpClient) { }

  getSaleRequest(){
    this.http.get<SaleRequest[]>('http://localhost:8080/api/getAllSaleRequests').pipe(retry(1), catchError((error: HttpErrorResponse) => {
      console.log(error.status);
      window.alert(error.error.message);
      return throwError('Error fetching data from serve');})).subscribe(resp=>{
      for(const i of(resp as any)){
        this.saleReqDb.push({
            id:i.id,
            name:i.name,
            email:i.email,
            phoneNumber:i.phoneNumber,
          })
        }
      });
    }

    addSaleRequest(saleRequest:SaleRequest){
      return this.http.post('http://localhost:8080/api/sendSaleRequest',saleRequest).pipe(retry(0),
      catchError((error: HttpErrorResponse) => {
        console.log(error.error.message);
        window.alert(error.error);
        return throwError('Error fetching data from server');}));
    }
  }
