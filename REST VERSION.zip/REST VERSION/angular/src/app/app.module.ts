import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule } from "@angular/forms";
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { UpdateuserComponent } from './updateuser/updateuser.component';
import { UpdatepropertyComponent } from './updateproperty/updateproperty.component';
import { HomeComponent } from './home/home.component';
import { BuyerserviceService } from './buyerservice.service';
import { PropertyserviceService } from './propertyservice.service';
import { SaleComponent } from './sale/sale.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    UserhomeComponent,
    AdminhomeComponent,
    AdminloginComponent,
    UpdateuserComponent,
    UpdatepropertyComponent,
    SaleComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule
  ],
  providers: [BuyerserviceService,PropertyserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
