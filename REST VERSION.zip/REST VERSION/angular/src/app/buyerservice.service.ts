import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Buyer } from './buyer';

import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BuyerserviceService {

  constructor(private http: HttpClient) { }

  public tempBuyer:Buyer;
  public buyerDb:any[]=[];
  public flag:boolean=false;
  private url="http://localhost:8080/api"

  getBuyers()
  {
    this.http.get<Buyer[]>(this.url+'/getAll').pipe(retry(1), catchError((error: HttpErrorResponse) => {
      console.log(error.status);
      window.alert(error.error.message);
      return throwError('Error fetching data from serve');})).subscribe(resp=>{
      for(const i of(resp as any)){
        this.buyerDb.push({
          id:i.id,
          email:i.email,
          password:i.password,
          name:i.name,
          phoneNo:i.phoneNo,
          city:i.city,
          state:i.state
        })
      }
    });
  }

  userExists(email:string){
    for(let i=0; i<this.buyerDb.length;i++){
      if(email==this.buyerDb[i].email)
         return true;
    }
    return false;
  }

  checkUser(email:string,password:string){
    this.http.post(this.url+'/login',{"email":email,"password":password}).pipe(retry(1), catchError((error: HttpErrorResponse) => {
      console.log(error.status);
      window.alert(error.error.message);
      return throwError('Error fetching data from serve');})).subscribe((resp:Buyer)=>{
      this.tempBuyer=resp;
      console.log(resp);
      this.flag=true;
    });  
  }

addBuyer(Buyer:Buyer)
  {
    this.buyerDb.push(Buyer);
    return this.http.post(this.url+'/register',Buyer).pipe(retry(1), catchError((error: HttpErrorResponse) => {
      console.log(error.status);
      window.alert(error.error.message);
      return throwError('Error fetching data from serve');}));
  }

  updateBuyer(id:any,Buyer:Buyer){
    return this.http.put(this.url+'/updateuser',Buyer).pipe(retry(1), catchError((error: HttpErrorResponse) => {
      window.alert(error.error.message);
      return throwError('Error fetching data from serve');}));
  }
}
