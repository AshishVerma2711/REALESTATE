import { Component, OnInit } from '@angular/core';
import { BuyerserviceService } from '../buyerservice.service';
import { Router } from '@angular/router';
import { Buyer } from '../buyer';

@Component({
  selector: 'app-updateuser',
  templateUrl: './updateuser.component.html',
  styleUrls: ['./updateuser.component.css']
})
export class UpdateuserComponent implements OnInit {

  constructor(private buySer:BuyerserviceService,private route:Router) { }
  currentUser:Buyer=this.buySer.tempBuyer;
  flagName:boolean=false;
  flagPhoneNo:boolean=false;
  flagCity:boolean=false;
  flagState:boolean=false;
  flagPassword:boolean=false;

  ngOnInit(): void {
  }
  
  changeName(){
    this.flagName=true;
    this.flagPhoneNo=false;
    this.flagCity=false;
    this.flagState=false;
    this.flagPassword=false;
    return;
  }
  changePhoneNo(){
    this.flagName=false;
    this.flagPhoneNo=true;
    this.flagCity=false;
    this.flagState=false;
    this.flagPassword=false;
    return;
  }
  changeCity(){
    this.flagName=false;
    this.flagPhoneNo=false;
    this.flagCity=true;
    this.flagState=false;
    this.flagPassword=false;
    return;
  }
  changeState(){
    this.flagName=false;
    this.flagPhoneNo=false;
    this.flagCity=false;
    this.flagState=true;
    this.flagPassword=false;
    return;
  }
  changePassword(){
    this.flagName=false;
    this.flagPhoneNo=false;
    this.flagCity=false;
    this.flagState=false;
    this.flagPassword=true;
    return;
  }
  updateName(){
    var newName=(<HTMLInputElement>document.getElementById("newName")).value;
    var pswd=(<HTMLInputElement>document.getElementById("password")).value;
    if(pswd!=""|| newName!=""){
      if(this.currentUser.password==pswd){
        this.currentUser.name=newName;
        this.buySer.updateBuyer(this.currentUser.id,this.currentUser).subscribe();
        this.flagName=false;
      }
      else{
        document.getElementById("error").innerHTML="Password is Incorrect!"
      }
    }
    else{
      document.getElementById("error").innerHTML="Fill all the entries"
    }
    return;
  }
  updatePhoneNo(){
    var newPhoneNo=(<HTMLInputElement>document.getElementById("newPhoneNo")).value;
    var pswd=(<HTMLInputElement>document.getElementById("password")).value;
    if(pswd!=""|| newPhoneNo!=""){
      if(this.currentUser.password==pswd){
        this.currentUser.phoneNo=newPhoneNo;
        this.buySer.updateBuyer(this.currentUser.id,this.currentUser).subscribe();
        this.flagPhoneNo=false;
      }
      else{
        document.getElementById("error").innerHTML="Password is Incorrect!"
      }
    }
    else{
      document.getElementById("error").innerHTML="Fill all the entries"
    }
    return;
  }
  updateCity(){
    var newCity=(<HTMLInputElement>document.getElementById("newCity")).value;
    var pswd=(<HTMLInputElement>document.getElementById("password")).value;
    if(pswd!=""||newCity!=""){
      if(this.currentUser.password==pswd){
        this.currentUser.city=newCity;
        this.buySer.updateBuyer(this.currentUser.id,this.currentUser).subscribe();
        this.flagCity=false;
      }
      else{
        document.getElementById("error").innerHTML="Password is Incorrect!"
      }
    }
    else{
      document.getElementById("error").innerHTML="Fill all the entries"
    }
    return;
  }
  updateState(){
    var newState=(<HTMLInputElement>document.getElementById("newState")).value;
    var pswd=(<HTMLInputElement>document.getElementById("password")).value;
    if(pswd!=""|| newState!=""){
      if(this.currentUser.password==pswd){
        this.currentUser.state=newState;
        this.buySer.updateBuyer(this.currentUser.id,this.currentUser).subscribe();
        this.flagState=false;
      }
      else{
        document.getElementById("error").innerHTML="Password is Incorrect!"
      }
    }
    else{
      document.getElementById("error").innerHTML="Fill all the entries"
    }
    return;
  }
  updatePassword(){
    var pswd=(<HTMLInputElement>document.getElementById("oldPassword")).value;
    var newPswd=(<HTMLInputElement>document.getElementById("newPassword")).value;
    var newPswd2=(<HTMLInputElement>document.getElementById("newPassword2")).value;
    if(pswd!=""||newPswd!=""||newPswd2!=""){
    if(this.currentUser.password==pswd){
        if(newPswd==newPswd2){
          this.currentUser.password=newPswd;
          this.buySer.updateBuyer(this.currentUser.id,this.currentUser).subscribe();
          this.flagPassword=false;
        }
        else{
          document.getElementById("error").innerHTML="Type Same Password!"
        }
    }
    else{
      document.getElementById("error").innerHTML="Current Password is Incorrect!"
    }
  }
  else{
    document.getElementById("error").innerHTML="Fill all the entries"
  }
    return;
  }
}
