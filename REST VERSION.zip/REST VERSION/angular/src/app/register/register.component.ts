import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BuyerserviceService } from '../buyerservice.service';
import { Validators, FormGroup, FormControl } from '@angular/forms';
import { Buyer } from '../buyer';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private buyerSer:BuyerserviceService,private router:Router) { }

  ngOnInit(): void {
    this.buyerSer.getBuyers();
  }
  signups=new FormGroup({
    name: new FormControl('',[Validators.minLength(2),Validators.required]),
    phoneNumber: new FormControl('',[Validators.pattern('[0-9]{10}'),Validators.required]),
    email: new FormControl('', [Validators.email,Validators.required]),
    password: new FormControl('',[Validators.minLength(8),Validators.required])
  });
signup(){
  let name = this.signups.get('name').value;
      let phoneNo = this.signups.get('phoneNumber').value;
      let emails = this.signups.get('email').value;
      let pass= this.signups.get('password').value;
      let l=this.buyerSer.buyerDb.length;
      if(name!=""||phoneNo!=""||emails!=""||pass!=""){
      let id= Number.parseInt(this.buyerSer.buyerDb[l-1].id)+1;
      
        if(this.buyerSer.userExists(emails)){
              document.getElementById("exists").innerHTML="User with same email already existed";
              return;
          }
      let temp:Buyer=new Buyer(id.toString(),emails,pass,name,phoneNo,"NONE","NONE");
      this.buyerSer.addBuyer(temp).subscribe(data=>{console.log(data)}); 
      this.router.navigateByUrl("/login"); 
    }
    else{
      document.getElementById("exists").innerHTML="Fill all the fields!"
    }
    return;
      // alert("Successfully registered"+id+" "+emails);
}
}