import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updateproperty',
  templateUrl: './updateproperty.component.html',
  styleUrls: ['./updateproperty.component.css']
})
export class UpdatepropertyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
