import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BuyerserviceService } from '../buyerservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private buyerSer:BuyerserviceService,private router:Router) { }

  ngOnInit(): void {
    this.buyerSer.getBuyers();
    console.log(this.buyerSer.buyerDb);
  }
  custlogin = new FormGroup({
    email: new FormControl('', [Validators.email]),
    pass: new FormControl('',)
  });


  login() {
  
    let email = this.custlogin.get('email').value;
    let pass = this.custlogin.get('pass').value;
    
    for(let i=0;i<this.buyerSer.buyerDb.length;i++) {
      if (this.buyerSer.buyerDb[i].email == email&&this.buyerSer.buyerDb[i].password==pass){     
        console.log(this.buyerSer.buyerDb[i].email);
        this.buyerSer.tempBuyer=this.buyerSer.buyerDb[i];
        this.buyerSer.flag=true;
        break;
      }
    }
      if (this.buyerSer.flag) {
        this.router.navigateByUrl("/userHome");
        alert("Successfull login"+this.buyerSer.tempBuyer.name);     
    }
  }
}
