import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Buyer } from './buyer';

@Injectable({
  providedIn: 'root'
})
export class BuyerserviceService {

  constructor(private http: HttpClient) { }

  public tempBuyer:Buyer;
  public buyerDb:any[]=[];
  public flag:boolean=false;

  getBuyers()
  {
    this.http.get<Buyer[]>('http://localhost:3000/buyer').subscribe(resp=>{
      for(const i of(resp as any)){
        this.buyerDb.push({
          id:i.id,
          email:i.email,
          password:i.password,
          name:i.name,
          phoneNo:i.phoneNo,
          city:i.city,
          state:i.state
        })
      }
    });
  }
  addBuyer(Buyer:Buyer)
  {
    return this.http.post('http://localhost:3000/buyer',Buyer);
  }

  updateBuyer(id:any,Buyer:Buyer){
    return this.http.put('http://localhost:3000/buyer/'+id,Buyer);
  }
  getUserById(id:any)
  {
    return this.http.get('http://localhost:3000/buyer/'+id);
  }
}
