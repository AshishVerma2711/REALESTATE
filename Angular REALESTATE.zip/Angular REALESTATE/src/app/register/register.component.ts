import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BuyerserviceService } from '../buyerservice.service';
import { Validators, FormGroup, FormControl } from '@angular/forms';
import { Buyer } from '../buyer';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private buyerSer:BuyerserviceService,private router:Router) { }

  ngOnInit(): void {
    this.buyerSer.getBuyers();
    console.log(this.buyerSer.buyerDb);
  }
  signups=new FormGroup({
    name: new FormControl(''),
    phoneNumber: new FormControl(''),
    email: new FormControl('', [Validators.email]),
    password: new FormControl('')
  });
signup(){
  let name = this.signups.get('name').value;
      let phoneNo = this.signups.get('phoneNumber').value;
      let emails = this.signups.get('email').value;
      let pass= this.signups.get('password').value;
      let l=this.buyerSer.buyerDb.length;
      let id=this.buyerSer.buyerDb[l-1].id+1;
      for(let i=0;i<this.buyerSer.buyerDb.length;i++){
          if(emails==this.buyerSer.buyerDb[i].email){
              document.getElementById("exists").innerHTML="User with same email already existed";
              return;
          }
      }
      let temp:Buyer=new Buyer(id,emails,pass,name,phoneNo,"NONE","NONE");
      this.buyerSer.addBuyer(temp).subscribe(data=>{console.log(data)}); 
      this.router.navigateByUrl("/login"); 
      alert("Successfully registered"+id+" "+emails);
      
}
}