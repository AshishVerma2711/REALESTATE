import { Component, OnInit } from '@angular/core';
import { BuyerserviceService } from '../buyerservice.service';
import { Router } from '@angular/router';
import { Buyer } from '../buyer';
import { NONE_TYPE } from '@angular/compiler';

@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {

  constructor(private buySer:BuyerserviceService,private route:Router) { }
  currentUser:Buyer=this.buySer.tempBuyer;
  ngOnInit(): void {
  }
logout(){
 this.buySer.tempBuyer=null;
 this.currentUser=this.buySer.tempBuyer;
}
}
